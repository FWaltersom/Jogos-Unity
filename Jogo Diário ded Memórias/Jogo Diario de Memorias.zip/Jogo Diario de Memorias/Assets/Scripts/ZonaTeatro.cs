using UnityEngine;
using UnityEngine.InputSystem;

public class ZonaTeatro : MonoBehaviour
{
    public GameObject dica;
    public GameObject painelHistoria;
    public GameObject painelPergunta;

    private Collider2D zona;
    private Collider2D colJogador;
    private PlayerController jogador;
    private bool perto;

    void Start()
    {
        zona = GetComponent<Collider2D>();
        GameObject p = GameObject.FindWithTag("Player");

        if (p == null)
        {
            Debug.LogError("ZonaTeatro: nenhum objeto com a Tag Player");
            return;
        }

        jogador = p.GetComponent<PlayerController>();
        colJogador = p.GetComponent<Collider2D>();
    }

    void Update()
    {
        if (jogador == null || colJogador == null) return;

        bool aberto = painelHistoria.activeSelf || painelPergunta.activeSelf;

        bool dentro = zona.OverlapPoint(jogador.transform.position)
                   || zona.OverlapPoint(colJogador.bounds.center);

        if (dentro != perto)
        {
            perto = dentro;
            Debug.Log(perto ? "Entrou na zona do teatro" : "Saiu da zona do teatro");
        }

        if (!aberto && dica.activeSelf != perto)
            dica.SetActive(perto);

        bool apertouE = Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame;

        if (perto && !aberto && apertouE)
            Abrir();
    }

    void Abrir()
    {
        Debug.Log("Abrindo a historia");
        painelHistoria.SetActive(true);
        dica.SetActive(false);
        jogador.enabled = false;
        jogador.GetComponent<Animator>().SetBool("isWalking", false);
    }

    public void IrParaPergunta()
    {
        painelHistoria.SetActive(false);
        painelPergunta.SetActive(true);
    }

    public void Fechar()
    {
        painelHistoria.SetActive(false);
        painelPergunta.SetActive(false);
        jogador.enabled = true;
    }
}