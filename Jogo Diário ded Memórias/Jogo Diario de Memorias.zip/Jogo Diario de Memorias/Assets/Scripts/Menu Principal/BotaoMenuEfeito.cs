using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Coloque em cada botão do menu. Faz o mouse selecionar o botão ao passar por cima
/// (assim só um botão fica "selected" por vez) e aplica um leve aumento de escala.
/// A troca de sprite normal/selected é feita pelo próprio Button (Transition = Sprite Swap).
/// </summary>
[RequireComponent(typeof(Button))]
public class BotaoMenuEfeito : MonoBehaviour, IPointerEnterHandler, ISelectHandler, IDeselectHandler
{
    [SerializeField] private float escalaSelecionado = 1.06f;
    [SerializeField] private float velocidade = 12f;

    private Vector3 escalaAlvo = Vector3.one;

    private void OnEnable()
    {
        transform.localScale = Vector3.one;
        escalaAlvo = Vector3.one;
    }

    private void Update()
    {
        // unscaledDeltaTime para funcionar mesmo com Time.timeScale = 0
        transform.localScale = Vector3.Lerp(transform.localScale, escalaAlvo, Time.unscaledDeltaTime * velocidade);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        EventSystem.current.SetSelectedGameObject(gameObject);
    }

    public void OnSelect(BaseEventData eventData)
    {
        escalaAlvo = Vector3.one * escalaSelecionado;
    }

    public void OnDeselect(BaseEventData eventData)
    {
        escalaAlvo = Vector3.one;
    }
}
