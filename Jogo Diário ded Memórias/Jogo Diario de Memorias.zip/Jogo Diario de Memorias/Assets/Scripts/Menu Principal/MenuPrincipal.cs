using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Controla o menu principal do Diário de Memórias.
/// Coloque este script em um GameObject vazio (ex.: "MenuController") dentro do Canvas.
/// </summary>
public class MenuPrincipal : MonoBehaviour
{
    [Header("Botões (na ordem de cima para baixo)")]
    [SerializeField] private Button botaoNovoJogo;
    [SerializeField] private Button botaoDiario;
    [SerializeField] private Button botaoConfiguracoes;
    [SerializeField] private Button botaoSair;

    [Header("Painéis opcionais")]
    [SerializeField] private GameObject painelDiario;
    [SerializeField] private GameObject painelConfiguracoes;

    [Header("Cena do jogo (precisa estar no Build Settings)")]
    [SerializeField] private string nomeCenaJogo = "Fase1";

    private void Start()
    {
        botaoNovoJogo.onClick.AddListener(NovoJogo);
        botaoDiario.onClick.AddListener(AbrirDiario);
        botaoConfiguracoes.onClick.AddListener(AbrirConfiguracoes);
        botaoSair.onClick.AddListener(Sair);

        if (painelDiario != null) painelDiario.SetActive(false);
        if (painelConfiguracoes != null) painelConfiguracoes.SetActive(false);

        SelecionarPrimeiro();
    }

    private void Update()
    {
        // Se o mouse clicou fora e nada ficou selecionado, volta a selecionar um botao
        // para o teclado/controle continuar funcionando.
        if (EventSystem.current.currentSelectedGameObject == null && AlgumaTeclaDeNavegacao())
        {
            SelecionarPrimeiro();
        }

        if (TeclaEscapeApertada()) FecharPaineis();
    }

    // Funciona tanto com o Input System novo quanto com o Input Manager antigo.
    private bool AlgumaTeclaDeNavegacao()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k != null && (k.upArrowKey.wasPressedThisFrame || k.downArrowKey.wasPressedThisFrame ||
                          k.leftArrowKey.wasPressedThisFrame || k.rightArrowKey.wasPressedThisFrame ||
                          k.wKey.wasPressedThisFrame || k.sKey.wasPressedThisFrame)) return true;
        var g = Gamepad.current;
        if (g != null && (g.dpad.up.wasPressedThisFrame || g.dpad.down.wasPressedThisFrame)) return true;
        return false;
#else
        return Input.GetAxisRaw("Vertical") != 0 || Input.GetAxisRaw("Horizontal") != 0;
#endif
    }

    private bool TeclaEscapeApertada()
    {
#if ENABLE_INPUT_SYSTEM
        return Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.Escape);
#endif
    }

    private void SelecionarPrimeiro()
    {
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(botaoNovoJogo.gameObject);
    }

    public void NovoJogo()
    {
        // Confere se a cena existe no Build Settings antes de carregar
        if (!Application.CanStreamedLevelBeLoaded(nomeCenaJogo))
        {
            Debug.LogError("Cena '" + nomeCenaJogo + "' nao encontrada. Confira se o nome e identico ao da cena " +
                           "(maiusculas, espacos) e se ela esta em File > Build Profiles > Scenes In Build.");
            return;
        }

        SceneManager.LoadScene(nomeCenaJogo);
    }

    public void AbrirDiario()
    {
        if (painelDiario != null) painelDiario.SetActive(true);
    }

    public void AbrirConfiguracoes()
    {
        if (painelConfiguracoes != null) painelConfiguracoes.SetActive(true);
    }

    public void FecharPaineis()
    {
        if (painelDiario != null) painelDiario.SetActive(false);
        if (painelConfiguracoes != null) painelConfiguracoes.SetActive(false);
        SelecionarPrimeiro();
    }

    public void Sair()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}