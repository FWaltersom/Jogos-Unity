using UnityEngine;

public class CameraSegue : MonoBehaviour
{
    [SerializeField] private Transform alvo;
    [SerializeField] private float suavidade = 8f;

    void LateUpdate()
    {
        if (alvo == null) return;
        Vector3 destino = new Vector3(alvo.position.x, alvo.position.y, transform.position.z);
        transform.position = Vector3.Lerp(transform.position, destino, suavidade * Time.deltaTime);
    }
}