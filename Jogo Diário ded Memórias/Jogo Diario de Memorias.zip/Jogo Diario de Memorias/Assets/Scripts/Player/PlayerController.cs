using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [SerializeField] private float velocidade = 4f;

    private Rigidbody2D rb;
    private Animator anim;
    private SpriteRenderer sr;
    private Vector2 movimento;

    // direção para onde o personagem olha (usada no Idle)
    private float dirX = 1f;
    private float dirY = 0f;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        var k = Keyboard.current;
        if (k == null) return;

        float x = 0f, y = 0f;
        if (k.dKey.isPressed || k.rightArrowKey.isPressed) x += 1f;
        if (k.aKey.isPressed || k.leftArrowKey.isPressed) x -= 1f;
        if (k.wKey.isPressed || k.upArrowKey.isPressed) y += 1f;
        if (k.sKey.isPressed || k.downArrowKey.isPressed) y -= 1f;

        movimento = new Vector2(x, y).normalized;
        bool andando = movimento.sqrMagnitude > 0.01f;

        if (x != 0)
        {
            // lado: o clip olha para a direita, espelha para a esquerda
            dirX = 1f;
            dirY = 0f;
            sr.flipX = x < 0;
        }
        else if (y != 0)
        {
            // cima ou baixo: sem espelhar
            dirX = 0f;
            dirY = y;
            sr.flipX = false;
        }

        anim.SetFloat("moveX", dirX);
        anim.SetFloat("moveY", dirY);
        anim.SetBool("isWalking", andando);
    }

    void FixedUpdate()
    {
        rb.linearVelocity = movimento * velocidade;
    }
}