using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PerguntaTeatro : MonoBehaviour
{
    public TMP_Text textoPergunta;
    public TMP_Text textoFeedback;
    public Button[] botoes;
    public GameObject botaoFechar;

    public string pergunta = "Em que data o Teatro Amazonas foi inaugurado?";
    public string[] opcoes =
    {
        "31 de dezembro de 1896",
        "7 de setembro de 1822",
        "15 de novembro de 1889",
        "1º de janeiro de 1900"
    };
    public int correta = 0;
    public string explicacao = "Foi inaugurado em 31 de dezembro de 1896.";

    void OnEnable()
    {
        textoPergunta.text = pergunta;
        textoFeedback.text = "";
        botaoFechar.SetActive(false);

        for (int i = 0; i < botoes.Length; i++)
        {
            botoes[i].interactable = true;
            botoes[i].GetComponentInChildren<TMP_Text>().text = opcoes[i];
            int escolha = i;
            botoes[i].onClick.RemoveAllListeners();
            botoes[i].onClick.AddListener(() => Responder(escolha));
        }
    }

    void Responder(int escolha)
    {
        string inicio = (escolha == correta) ? "Certo! " : "Errou! ";
        textoFeedback.text = inicio + explicacao;

        foreach (var b in botoes) b.interactable = false;
        botaoFechar.SetActive(true);
    }
}